<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\AffiliateOption;
use App\Order;
use App\BusinessSetting;
use App\User;
use App\Wallet;
use Session;
use Cookie;

class AffiliateController extends Controller
{
    //
    public function index(){
        return view('affiliate.index');
    }

    public function affiliate_option_store(Request $request){
        $affiliate_option = AffiliateOption::where('type', $request->type)->first();
        if($affiliate_option == null){
            $affiliate_option = new AffiliateOption;
        }
        $affiliate_option->type = $request->type;
        $affiliate_option->Percentage = $request->percentage;
        $affiliate_option->save();

        return back();
    }

    public function processAffiliatePoints(Order $order){
        if(\App\BusinessSetting::where('type', 'affiliate_system')->first()->value == 1){
            if(AffiliateOption::where('type', 'user_registration_first_purchase')->first()->status){
                if (Auth::check() && Auth::user()->orders == null) {
                    if(Auth::user()->referred_by != null){
                        $user = User::find(Auth::user()->referred_by);
                        if ($user != null) {
                            $amount = (AffiliateOption::where('type', 'user_registration_first_purchase')->first()->percentage * $order->grand_total)/100;
                            $user->balance += $amount;
                            $user->save();

                            $wallet = new Wallet;
                            $wallet->user_id = $user->id;
                            $wallet->amount = $amount;
                            $wallet->payment_method = 'Affiliate';
                            $wallet->payment_details = null;
                            $wallet->save();
                        }
                    }
                }
            }
            if(AffiliateOption::where('type', 'product_sharing')->first()->status){
                if(Cookie::has('product_referral_code') && Cookie::has('referred_product_id')){
                    $referral_code = Cookie::get('referral_code');
                    $product_id = $referral_code = Cookie::get('referred_product_id');

                    $referred_by_user = User::where('referral_code', $referral_code)->first();
                    if($referred_by_user != null){
                        foreach ($order->orderDetails as $key => $orderDetail) {
                            if($orderDetail->product_id == $product_id){
                                $amount = (AffiliateOption::where('type', 'product_sharing')->first()->percentage * $orderDetail->price)/100;
                                $referred_by_user->balance += $amount;
                                $referred_by_user->save();

                                $wallet = new Wallet;
                                $wallet->user_id = $referred_by_user->id;
                                $wallet->amount = $amount;
                                $wallet->payment_method = 'Affiliate';
                                $wallet->payment_details = null;
                                $wallet->save();
                            }
                        }
                    }
                }
            }
        }
    }
}
