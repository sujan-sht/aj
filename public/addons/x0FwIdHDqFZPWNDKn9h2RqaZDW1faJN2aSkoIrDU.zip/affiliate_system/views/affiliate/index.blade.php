@extends('layouts.app')

@section('content')

    <div class="row">
        <div class="col-lg-6">
            <div class="panel">
                <div class="panel-heading">
                    <h3 class="panel-title text-center">{{__('Basic Affiliate')}}</h3>
                </div>
                <div class="panel-body">
                    <form class="form-horizontal" action="{{ route('affiliate.store') }}" method="POST">
                        @csrf
                        <div class="form-group">
                            <input type="hidden" name="type" value="user_registration_first_purchase">
                            <div class="col-lg-4">
                                <label class="control-label">{{__('User Registration & First Purchase')}}</label>
                            </div>
                            <div class="col-lg-6">
                                @php
                                    if(\App\AffiliateOption::where('type', 'user_registration_first_purchase')->first() != null){
                                        $percentage = \App\AffiliateOption::where('type', 'user_registration_first_purchase')->first()->percentage;
                                        $status = \App\AffiliateOption::where('type', 'user_registration_first_purchase')->first()->status;
                                    }
                                    else {
                                        $percentage = null;
                                    }
                                @endphp
                                <input type="number" min="0" step="0.01" max="100" class="form-control" name="percentage" value="{{ $percentage }}" placeholder="Percentage of Order Amount" required>
                            </div>
                            <div class="col-lg-2">
                                <label class="control-label">%</label>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-lg-4">
                                <label class="control-label">{{__('Status')}}</label>
                            </div>
                            <div class="col-lg-8">
                                <label class="switch">
                                    <input value="1" name="status" type="checkbox" @if ($status)
                                        checked
                                    @endif>
                                    <span class="slider round"></span>
                                </label>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-lg-12 text-right">
                                <button class="btn btn-purple" type="submit">{{__('Save')}}</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="panel">
                <div class="panel-heading">
                    <h3 class="panel-title text-center">{{__('Product Sharing Affiliate')}}</h3>
                </div>
                <div class="panel-body">
                    <form class="form-horizontal" action="{{ route('affiliate.store') }}" method="POST">
                        @csrf
                        <div class="form-group">
                            <input type="hidden" name="type" value="product_sharing">
                            <div class="col-lg-4">
                                <label class="control-label">{{__('Product Sharing and Purchasing')}}</label>
                            </div>
                            <div class="col-lg-6">
                                @php
                                    if(\App\AffiliateOption::where('type', 'product_sharing')->first() != null){
                                        $percentage = \App\AffiliateOption::where('type', 'product_sharing')->first()->percentage;
                                        $status = \App\AffiliateOption::where('type', 'product_sharing')->first()->status;
                                    }
                                    else {
                                        $percentage = null;
                                    }
                                @endphp
                                <input type="number" min="0" step="0.01" max="100" class="form-control" name="percentage" value="{{ $percentage }}" placeholder="Percentage of Order Amount" required>
                            </div>
                            <div class="col-lg-2">
                                <label class="control-label">%</label>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-lg-4">
                                <label class="control-label">{{__('Status')}}</label>
                            </div>
                            <div class="col-lg-8">
                                <label class="switch">
                                    <input value="1" name="status" type="checkbox" @if ($status)
                                        checked
                                    @endif>
                                    <span class="slider round"></span>
                                </label>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-lg-12 text-right">
                                <button class="btn btn-purple" type="submit">{{__('Save')}}</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

@endsection
